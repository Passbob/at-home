package com.manggom.manngomControl;

public class Application {

    public static void main(String[] args) {
        SaleProductPage start = new SaleProductPage();

          start.startPurchase();

    }
}

